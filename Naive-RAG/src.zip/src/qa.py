from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from langchain_core.documents import Document

from embeddings import embed_texts
from prompt_builder import build_prompt
from vectore_store import search


def embed_question(question: str) -> List[float]:
    """Generate an embedding vector for a natural language query."""
    return embed_texts([question])[0]


def load_document_from_metadata(metadata: Dict[str, Any]) -> Optional[Document]:
    """Rebuild a Document from the chunk text stored in the vector store metadata."""
    text = metadata.get("text")
    if not text:
        return None
    return Document(page_content=text, metadata=metadata)


def get_relevant_documents(
    repo_path: Path,
    question: str,
    top_k: Optional[int] = None,
) -> List[Document]:
    """Search the repository vector store and return the top matching chunks.

    Only the highest-scoring chunk per source file is kept so the prompt
    stays diverse instead of being flooded with chunks from one file.
    """
    query_embedding = embed_question(question)
    results = search(repo_path, query_embedding, top_k=top_k)

    documents: List[Document] = []
    seen_sources: set[str] = set()

    for item in results:
        document = load_document_from_metadata(item)
        if document is None:
            continue

        source = document.metadata.get("source", "")
        if source in seen_sources:
            continue

        seen_sources.add(source)
        documents.append(document)

    return documents


def build_answer_prompt(
    question: str,
    documents: List[Document],
    max_chunks: int = 5,
) -> str:
    """Build the final prompt text for the model using retrieved documents."""
    return build_prompt(question, documents, max_chunks=max_chunks)


def prepare_qa_payload(
    repo_path: Path,
    question: str,
    top_k: Optional[int] = None,
    max_chunks: int = 5,
) -> Dict[str, Any]:
    """Prepare the prompt and document context for a repository QA query."""
    documents = get_relevant_documents(repo_path, question, top_k=top_k)
    return {
        "question": question,
        "prompt": build_answer_prompt(question, documents, max_chunks=max_chunks),
        "documents": documents,
    }
