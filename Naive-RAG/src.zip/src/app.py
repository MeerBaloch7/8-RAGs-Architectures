from __future__ import annotations

import argparse
import contextlib
import logging
import os
import warnings
from functools import lru_cache
from pathlib import Path
from typing import Optional

import torch

# Keep the terminal clean: no progress bars, warnings, or advisory messages.
os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
os.environ.setdefault("TRANSFORMERS_VERBOSITY", "error")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
warnings.filterwarnings("ignore")
logging.getLogger("transformers").setLevel(logging.ERROR)
logging.getLogger("huggingface_hub").setLevel(logging.ERROR)

from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline

from config import settings
from chunker import chunk_repository
from embeddings import embed_documents
from qa import prepare_qa_payload
from repo_crawler import clone_repo
from vectore_store import load_vector_store, persist_vector_store, vector_store_exists


@contextlib.contextmanager
def silence_stderr():
    """Redirect the OS-level stderr to /dev/null.

    Catches even warnings written by Rust/C extensions (e.g. hf_xet)
    that bypass Python's warnings and logging machinery.
    """
    devnull_fd = os.open(os.devnull, os.O_WRONLY)
    saved_fd = os.dup(2)
    os.dup2(devnull_fd, 2)
    try:
        yield
    finally:
        os.dup2(saved_fd, 2)
        os.close(saved_fd)
        os.close(devnull_fd)


def ensure_hf_token() -> None:
    if settings.HF_API_KEY:
        os.environ["HUGGINGFACEHUB_API_TOKEN"] = settings.HF_API_KEY


def resolve_repository_path(repo_ref: str, target_root: Path, branch: Optional[str], force: bool) -> Path:
    candidate = Path(repo_ref)
    if candidate.exists() and candidate.is_dir():
        return candidate.resolve()
    return clone_repo(repo_ref, branch=branch, target_root=target_root, force=force)


def build_repository_index(
    repo_path: Path,
    chunk_size: int,
    chunk_overlap: int,
    verbose: bool = False,
    rebuild: bool = False,
) -> int:
    if vector_store_exists(repo_path) and not rebuild:
        if verbose:
            print(f"Reusing existing vector store for {repo_path.name}.")
        return load_vector_store(repo_path)[0].ntotal

    if verbose:
        print(f"Indexing repository at {repo_path}")
    documents = chunk_repository(repo_path, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    if not documents:
        raise RuntimeError("No supported files were found in the repository to index.")

    if verbose:
        print(f"Embedding {len(documents)} chunks...")
    embeddings = embed_documents(documents)
    persist_vector_store(repo_path, embeddings, documents)
    return len(documents)


@lru_cache(maxsize=1)
def load_generation_pipeline(model_name: str):
    """Load the generation pipeline once and reuse it across questions."""
    ensure_hf_token()
    token_kwargs: dict = {}
    model_kwargs: dict = {"dtype": torch.bfloat16}
    if settings.HF_API_KEY:
        token_kwargs["token"] = settings.HF_API_KEY
        model_kwargs["token"] = settings.HF_API_KEY

    tokenizer = AutoTokenizer.from_pretrained(model_name, **token_kwargs)
    model = AutoModelForCausalLM.from_pretrained(model_name, **model_kwargs)

    device = 0 if torch.cuda.is_available() else -1
    generator = pipeline("text-generation", model=model, tokenizer=tokenizer, device=device)
    return generator, tokenizer


def format_model_prompt(tokenizer, prompt: str) -> str:
    """Wrap the RAG prompt in the model's chat template when one exists."""
    if not tokenizer.chat_template:
        return prompt

    messages = [
        {"role": "system", "content": "You are a code assistant for a GitHub repository."},
        {"role": "user", "content": prompt},
    ]
    try:
        return tokenizer.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True, enable_thinking=False
        )
    except TypeError:
        return tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)


def strip_thinking(text: str) -> str:
    """Remove a leftover thinking block that some chat models still emit."""
    stripped = text.lstrip()
    if stripped.startswith("<think>"):
        end = stripped.find("</think>")
        if end != -1:
            return stripped[end + len("</think>"):].strip()
    return stripped


def generate_answer(prompt: str, model_name: str, max_new_tokens: int = 128) -> str:
    generator, tokenizer = load_generation_pipeline(model_name)
    model_prompt = format_model_prompt(tokenizer, prompt)
    outputs = generator(
        model_prompt,
        max_new_tokens=max_new_tokens,
        do_sample=False,
        return_full_text=False,
    )
    return strip_thinking(outputs[0]["generated_text"].strip())


def print_sources(documents) -> None:
    if not documents:
        return
    print("Sources:")
    for index, document in enumerate(documents, start=1):
        source = document.metadata.get("source", "unknown")
        score = document.metadata.get("score")
        score_text = f" (score: {score:.2f})" if score is not None else ""
        print(f"  {index}. {source}{score_text}")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run the repository QA application: clone, index, and ask questions against repo code."
    )
    parser.add_argument("repo", help="GitHub repo (owner/repo) or local repository path.")
    parser.add_argument("--branch", default=None, help="Branch or tag to clone.")
    parser.add_argument("--target-root", default=str(settings.REPO_ROOT), help="Directory where cloned repositories are stored.")
    parser.add_argument("--force", action="store_true", help="Force re-cloning of an existing repository.")
    parser.add_argument("--question", default=None, help="Ask a question after indexing or loading the repository.")
    parser.add_argument("--model", default=settings.HF_LLM_MODEL, help="Hugging Face model identifier for generation.")
    parser.add_argument("--chunk-size", type=int, default=settings.CHUNK_SIZE, help="Max chunk size for repository splitting.")
    parser.add_argument("--chunk-overlap", type=int, default=settings.CHUNK_OVERLAP, help="Chunk overlap size for repository splitting.")
    parser.add_argument("--max-chunks", type=int, default=5, help="Max document chunks included in the prompt.")
    parser.add_argument("--max-new-tokens", type=int, default=256, help="Max tokens generated by the model.")
    parser.add_argument("--rebuild", action="store_true", help="Force re-indexing of the repository.")
    parser.add_argument("--verbose", action="store_true", help="Print question, prompt, and sources alongside the answer.")
    args = parser.parse_args()

    repo_path = resolve_repository_path(args.repo, Path(args.target_root), args.branch, args.force)

    with silence_stderr():
        indexed_chunks = build_repository_index(
            repo_path, args.chunk_size, args.chunk_overlap, verbose=args.verbose, rebuild=args.rebuild
        )
        if args.verbose:
            print(f"Indexed {indexed_chunks} chunks.")

        if args.question:
            payload = prepare_qa_payload(repo_path, args.question, max_chunks=args.max_chunks)

            if args.verbose:
                print(f"\nQuestion: {args.question}")
                print("\n=== Prompt ===")
                print(payload["prompt"])

            print(generate_answer(payload["prompt"], args.model, max_new_tokens=args.max_new_tokens))

            if args.verbose:
                print()
                print_sources(payload["documents"])
        else:
            print("Repository indexed. Use --question to ask a question against the vector store.")


if __name__ == "__main__":
    main()
